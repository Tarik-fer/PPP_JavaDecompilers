package Pacman9;

public class BonusGenerator 
{
	//create and returns a bonus object
	public Bonus createBonus(){		
		Bonus b = new Bonus();
		return b;		
	}
	
}