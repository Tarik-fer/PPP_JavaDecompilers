
1. first copy all the project in folder pacman and run MainScreen.java file . 
2. First Create Directory Pacman on C drive c:\Pacman.
3. past all the file into the pacman folder and run mainscreen.java file.